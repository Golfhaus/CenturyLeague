"""Recompute paired win effects from the archived compact outcomes. Python 3 stdlib only."""
import csv,json,math
from pathlib import Path
rows=list(csv.DictReader((Path(__file__).parent/'paired-outcomes.csv').open()))
def effect(cases,case,reference='control'):
 ds=[a[case]-a[reference] for a in cases.values()];n=len(ds);d=sum(ds)/n
 se=math.sqrt(sum((x-d)**2 for x in ds)/(n-1)/n)
 def wilson(k,z=2.241403):
  p=k/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
  return max(0,mid-half),min(1,mid+half)
 a=wilson(ds.count(1));b=wilson(ds.count(-1))
 return {'case':case,'reference':reference,'n':n,'liftPoints':100*d,'approximate95Points':[100*(d-1.96*se),100*(d+1.96*se)],'conservative95Points':[100*max(-1,a[0]-b[1]),100*min(1,a[1]-b[0])],'improved':ds.count(1),'worsened':ds.count(-1)}
for study in sorted({r['study']for r in rows}):
 selected=[r for r in rows if r['study']==study];cases={}
 for r in selected:cases.setdefault(r['fixture'],{})[r['arm']]=int(r['focalWin'])
 print(json.dumps({'study':study,'effects':[effect(cases,a)for a in sorted(next(iter(cases.values())))if a!='control']}))
